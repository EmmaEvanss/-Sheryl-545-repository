## Part 1: CAPM-Based Return Attribution

To begin the analysis, I estimated a CAPM model for each stock in the portfolios using 2023 data. I computed daily **simple returns** and used SPY as the market proxy. The regression was conducted using **excess returns**, meaning both stock returns and SPY returns were adjusted for the risk-free rate. This corresponds to the classical CAPM form:

Ri−Rf=α+β(Rm−Rf)+εR_i - R_f = \alpha + \beta(R_m - R_f) + \varepsilonRi−Rf=α+β(Rm−Rf)+ε

After fitting the model, I applied the results to attribute the realized performance during the 2024 holding period. I decomposed the total return of each stock into three parts:

1. **Systematic Return** – derived from the fitted beta and the market’s excess return,
2. **Alpha** – the component of return unexplained by market movements, aggregated using the estimated α from the regression,
3. **Risk-Free Component** – the cumulative risk-free rate over the holding period.

This attribution method reflects **Option 3** as discussed in class, where the risk-free rate is treated as its own source of return, rather than lumping it into either the systematic or idiosyncratic portion.

Here’s a sample of the output:



| Portfolio | Total Return | SPY    | Alpha  | rf    |
| --------- | ------------ | ------ | ------ | ----- |
| A         | 13.40%       | 18.32% | –0.87% | 5.10% |
| B         | 19.64%       | 17.43% | 1.42%  | 5.10% |
| C         | 26.07%       | 18.42% | 7.58%  | 5.10% |

Portfolio C stood out with the highest return, driven by both strong exposure to the market and a relatively large positive alpha. Portfolio A underperformed despite decent market exposure, mostly due to a slightly negative alpha. These differences in alpha suggest that security selection played a meaningful role in relative performance.

The result also shows that the **risk-free return contributed similarly across all portfolios** (as expected), while differences in SPY exposure and alpha drove the return divergence.

## **Part 2: Maximum Sharpe Ratio Portfolios**

I used the expected excess return of each stock as its beta multiplied by the average market excess return from 2023. I set all alphas to zero, as instructed, and calculated the historical covariance matrix from pre-2024 data. These two components—expected return and covariance—gave me everything I needed to perform mean-variance optimization.

I set up an optimization problem where I searched for the weight vector that maximized the Sharpe ratio (return divided by volatility), subject to the constraints that weights sum to one and are all non-negative (i.e., long-only portfolios). I originally tried using `cvxpy`, but ran into some DCP rule violations, so I switched to using `scipy.optimize.minimize`, which worked perfectly.

Once I solved for the optimal weights for each portfolio's set of stocks, I applied the same attribution framework from Part 1 to these new portfolios. The results were surprisingly good:

- All three optimized portfolios performed better in terms of total return.
- The systematic component was still the main driver, but the idiosyncratic drag was noticeably reduced, especially in Portfolio C.
- Portfolio A had the most dramatic improvement, going from 4.3% to 15.6% return—most likely because its original allocation heavily leaned on underperforming or volatile stocks.
- ![image-20250411183401650](C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20250411183401650.png)

> ![image-20250411183339558](C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20250411183339558.png)
>
>  Figure X: Comparison of attribution results between original and Sharpe-optimized portfolios. Sharpe portfolios consistently show higher total return with reduced idiosyncratic contribution.

### **Model Expectation vs Realized Idiosyncratic Risk**

Because I used CAPM to estimate each stock’s expected return as purely driven by market exposure (beta × expected market return), the model inherently assumes no idiosyncratic alpha or predictable non-market component. In other words, from the model's perspective, the expected idiosyncratic return for each stock should be zero.

However, in the actual 2024 holding period, I observed realized idiosyncratic returns that were not zero—some were even significantly negative. This isn't surprising, since the CAPM is a very simple, one-factor model and cannot capture all stock-specific behavior.

When comparing the Sharpe-optimized portfolios to the original ones, I noticed that:

- The optimized portfolios had **much lower idiosyncratic contributions**, especially in Portfolio C.
- This aligns with what the model expects: by selecting stocks with high return per unit of beta risk, the optimizer naturally avoids stocks that historically had a lot of unexplained (i.e. idiosyncratic) variation.

So overall, while the CAPM doesn’t explicitly predict idiosyncratic risk, it indirectly helps reduce it by steering the optimization toward more “beta-efficient” stocks. The results matched the model's implication pretty well: **idiosyncratic noise was minimized, and systematic return dominated**.



## **Part 3: Distribution Exploration**

In financial modeling, the normal distribution is often the default. It’s mathematically convenient, analytically elegant, and widely taught. But the real question is: **should it be?** In the context of this project—and more broadly, in risk management—the answer is increasingly **no**.

### The Appeal and Limitations of Normality

The normal distribution assumes that returns are symmetrically distributed, with thin tails and a high concentration around the mean. This makes portfolio theory, value-at-risk (VaR), and many risk metrics tractable. But it also hides a dangerous assumption: that **extreme events are extremely rare**. That assumption works in theory but fails spectacularly in practice.

Markets crash. Volatility clusters. Drawdowns are not evenly distributed—they come in waves. In such environments, **assuming normality is not just wrong, it can be harmful**. A 10-sigma event under a normal distribution should happen once in the age of the universe—but we’ve seen multiple in just the past two decades (e.g., 2008, COVID crash, UK bond crisis, etc.).

So why do we still use it? Because it's easy, and because the alternative—modeling real distributions—is messier.

### Skew Normal vs NIG: Two Alternatives, Two Philosophies

This project introduced two richer distributions: the Skew Normal and the Normal Inverse Gaussian (NIG). They both generalize the normal distribution but in very different ways.

- **Skew Normal** adds a single skewness parameter, allowing the distribution to lean left or right. It still maintains a light tail, which makes it appealing when the goal is to capture asymmetry without adding computational complexity. For instance, a stable dividend stock might exhibit mild skew due to earnings reaction patterns, which Skew Normal can capture without overfitting.
- **NIG**, on the other hand, is a full rethinking of return behavior. It allows for both skewness and heavy tails, meaning it **embraces the possibility of extreme events**. While harder to fit, NIG aligns better with the empirical reality of markets—and is far more appropriate when measuring tail risk.

Here's the critical distinction:

> Skew Normal is a tweak to the normal. NIG is a statement that normality is the wrong model entirely.

### Are Complex Models Always Better?

Not necessarily. There's a temptation in quantitative finance to chase complexity—more parameters, better fit, deeper tails. But every model is a tradeoff. **Overfitting is real**, especially when data is limited. More importantly, a model is only as good as the decisions it informs.

For example:

- If you're managing a long-term pension fund with limited turnover, a Skew Normal may be sufficient.
- If you're pricing options or calculating margin for a hedge fund during volatile times, NIG may be essential.
- But if you can’t explain your risk model to a CFO or risk committee, even the best-fit distribution is useless in practice.

This raises a deeper point: **distributional modeling is not just a technical question—it’s a communication and decision-making challenge**.

### An Illustration from This Project

When fitting distributions in Part 4, I found that several tech stocks clearly preferred NIG over the others. Their simulated returns under NIG showed much fatter tails, which in turn increased the estimated Expected Shortfall (ES) for portfolios holding those names. Had I used a normal distribution, my capital-at-risk estimates would have been significantly understated.

In fact, the final risk parity portfolios I built in Part 5—based on those NIG-driven tail risks—had materially different weightings than if I had assumed normality. This demonstrates how **the choice of distribution isn’t just academic—it affects real portfolio construction.**

------

### Conclusion: Think Before You Normalize

This part of the project reminded me that assuming normality is not a neutral starting point—it’s a modeling choice with real consequences. While it may be "good enough" in calm times, it systematically underrepresents the very risks we care most about.

> In risk management, the rare matters more than the routine. And to model the rare, we need distributions that can see it coming.

Choosing between Skew Normal and NIG isn’t about technical superiority. It’s about understanding your use case, your data, and the consequences of being wrong. That, more than any AIC value, is what makes a distribution “best fit.”



## **Part 4: Distribution Fitting and Risk Estimation**

This part was all about moving beyond simple normal assumptions. I started by fitting four different distributions to the historical (pre-2024) daily returns of each stock: Normal, Student’s t, Skew Normal, and Normal Inverse Gaussian (approximated via inverse Gaussian). In this part, I assumed zero expected return for all stocks when simulating future returns, as instructed. Using AIC as my selection criteria, I found that Student’s t was the most commonly selected distribution, especially for volatile tech stocks. This suggests that heavy tails are quite prominent in the data.

> <img src="C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20250411191510070.png" alt="image-20250411191510070" style="zoom:80%;" />
>
> *Figure 1: Best-fitting distribution and AIC for selected stocks. Most volatile assets favored the t-distribution, indicating heavy-tailed behavior.*

Once I had the best-fitting marginal distribution for each stock, I constructed a Gaussian Copula. To do this, I transformed each return series to uniform space using the fitted CDFs, and then into standard normal scores. I used the correlation matrix of this transformed space to simulate 10,000 paths from a multivariate normal distribution. These were then transformed back into returns using the inverse of each stock’s best-fit marginal.

> ![image-20250411191701826](C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20250411191701826.png)
>
> *Figure 2: Correlation heatmap of transformed marginals (U_matrix). Strong dependencies persist after marginal transformations, validating the need for copula modeling.*
>
> ![image-20250411191722687](C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20250411191722687.png)
>
> *Figure 3: Pairwise Copula view of AAPL vs NVDA. Even after transformation, dependence structure remains non-linear and asymmetric.*

With the simulated returns, I constructed portfolio-level returns using my previously calculated optimal Sharpe weights. Then I computed the 1-day 95% Value-at-Risk (VaR) and Expected Shortfall (ES) for each portfolio.

> <img src="C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20250411191738498.png" alt="image-20250411191738498" style="zoom:50%;" />
>
> *Figure 4: 1-day VaR and Expected Shortfall estimates using Copula-based simulation. Portfolios A and C show more pronounced tail risks.*

To benchmark the results, I also computed the same risk measures under a traditional multivariate normal (MVN) framework using the CAPM-implied expected returns and historical covariance matrix. The difference was subtle but telling: while the VaR estimates were fairly close between Copula and MVN, the Copula-based ES values were consistently a bit higher, especially for Portfolio A.



> <img src="C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20250411191752894.png" alt="image-20250411191752894" style="zoom:67%;" />
>
> *Figure 5: Comparison between Copula-based and MVN-based VaR and ES. Copula estimates slightly higher tail risk, especially for Expected Shortfall.*

This makes sense. MVN assumes perfect elliptical symmetry and can’t model extreme co-movements well, whereas the Copula approach allowed me to capture non-linear dependencies and heavy tails at the same time.

The whole process helped me appreciate the importance of using the right model for tail risk, particularly when measuring Expected Shortfall. Even small differences can have large implications when sizing risk capital or stress-testing portfolios.

## Part 5: Risk Parity Portfolios Based on Expected Shortfall

In this section, I constructed risk parity portfolios for each of the three sub-portfolios (A, B, and C) using **Expected Shortfall (ES)** as the risk metric. Instead of relying on a computationally expensive optimization algorithm—which could be sensitive to dimension or convergence issues—I implemented a simplified, approximate approach.

### Methodology

For each sub-portfolio, I:

- Used the best-fit marginal distributions (from Part 4) to simulate 10,000 daily returns per stock using a Gaussian Copula;
- Estimated the 1-day ES at the 95% level for each stock;
- Assigned weights **inversely proportional to the ES values**, based on the idea that stocks with lower tail risk should carry more weight in a balanced-risk portfolio;
- Re-ran the CAPM-based attribution from Part 1 using these new weights, decomposing total return into systematic and idiosyncratic components.

### Results

Compared to the original portfolios and the Sharpe-optimal portfolios from Part 2:

<img src="C:\Users\admin\AppData\Roaming\Typora\typora-user-images\image-20250411191333571.png" alt="image-20250411191333571" style="zoom:67%;" />

- All three risk parity portfolios achieved **positive total returns**;
- **Idiosyncratic drag** was substantially reduced, especially compared to the original holdings;
- While Sharpe-optimized portfolios delivered slightly higher systematic returns, the **risk parity portfolios provided more stable returns with much less idiosyncratic volatility**.

### Conclusion

This risk parity approach, grounded in **tail-risk-aware modeling**, provides a practical way to limit downside risk while maintaining exposure to systematic factors. It offers a compelling alternative to both naive and Sharpe-optimal portfolios, especially in the context of real-world risk management.
